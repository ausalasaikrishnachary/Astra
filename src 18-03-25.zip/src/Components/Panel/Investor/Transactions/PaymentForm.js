import React, { useEffect, useState } from "react";
import InvestorHeader from "../../../Shared/Investor/InvestorNavbar";
import { 
  Container, 
  Typography, 
  Box, 
  Grid, 
  TextField, 
  FormControlLabel, 
  Checkbox, 
  Button 
} from "@mui/material";
import { useLocation } from "react-router-dom";

function PaymentForm() {
  const [formData, setFormData] = useState({
    escrow_id: "",
    property_name: "",
    property_type: "",
    property_value: "",
    no_of_investors: "",
    total_units: "",
    price_per_unit: "",
    transaction_type: "Purchase",
    available_units: "",
    no_of_units_purchased: "",
    paid_amount: "",
    remaining_amount: "",
  });

  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const propertyId = queryParams.get("property_id");

  useEffect(() => {
    if (propertyId) {
      fetchPropertyData(propertyId);
      fetchEscrowData(propertyId);
    }
  }, [propertyId]);

  // Fetch Property Data
  const fetchPropertyData = async (propertyId) => {
    try {
      const response = await fetch(`http://175.29.21.7:83/property/${propertyId}/`);
      if (!response.ok) {
        throw new Error("Failed to fetch property data");
      }
      const data = await response.json();

      setFormData((prevData) => ({
        ...prevData,
        property_name: data.property_name,
        property_type: data.property_type,
        property_value: data.property_value,
        total_units: data.total_units,
        available_units: data.available_units,
        no_of_investors: data.no_of_investors,
        price_per_unit: (data.property_value / data.total_units).toFixed(2),
      }));
    } catch (error) {
      console.error("Error fetching property data:", error);
    }
  };

  // Fetch Escrow Data
  const fetchEscrowData = async (propertyId) => {
    try {
      const response = await fetch(`http://175.29.21.7:83/escrow/account/property/${propertyId}/`);
      if (!response.ok) {
        throw new Error("Failed to fetch escrow data");
      }
      const data = await response.json();

      setFormData((prevData) => ({
        ...prevData,
        escrow_id: data.escrow_id,
        paid_amount: data.deposit_amount
      }));
    } catch (error) {
      console.error("Error fetching escrow data:", error);
    }
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prevData) => {
      const updatedData = {
        ...prevData,
        [name]: type === "checkbox" ? checked : value,
      };

      // Calculate total value and remaining amount dynamically
      if (name === "no_of_units_purchased") {
        updatedData.total_value = (updatedData.no_of_units_purchased * updatedData.price_per_unit).toFixed(2);
        updatedData.remaining_amount = (updatedData.total_value - updatedData.paid_amount).toFixed(2);
      }
      if (name === "paid_amount") {
        updatedData.remaining_amount = (updatedData.total_value - value).toFixed(2);
      }

      return updatedData;
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Form submitted", formData);
  };

  return (
    <>
      <InvestorHeader />
      <Container maxWidth="xl" sx={{ padding: 3 }}>
        <Typography variant="h4" gutterBottom textAlign="center">
          Payment
        </Typography>
        <Box component="form" onSubmit={handleSubmit} sx={{ width: "100%" }}>
          <Grid container spacing={2}>
            {Object.keys(formData).map((key) => (
              <Grid item xs={12} md={3} key={key}>
                {typeof formData[key] === "boolean" ? (
                  <FormControlLabel
                    control={
                      <Checkbox
                        name={key}
                        checked={formData[key]}
                        onChange={handleChange}
                      />
                    }
                    label={key.replace(/_/g, " ")}
                  />
                ) : (
                  <TextField
                    fullWidth
                    label={key.replace(/_/g, " ")}
                    name={key}
                    value={formData[key] || ""}
                    onChange={handleChange}
                    variant="outlined"
                    InputProps={{
                      readOnly: [
                        "property_name",
                        "property_type",
                        "property_value",
                        "total_units",
                        "available_units",
                        "price_per_unit",
                        "total_value",
                        "remaining_amount",
                        "escrow_id", // Make escrow_id read-only
                      ].includes(key),
                    }}
                  />
                )}
              </Grid>
            ))}
          </Grid>
          <Box sx={{ marginTop: 3 }}>
            <Button type="submit" variant="contained" sx={{ color: "white", width: "200px" }}>
              Submit
            </Button>
          </Box>
        </Box>
      </Container>
    </>
  );
}

export default PaymentForm;
