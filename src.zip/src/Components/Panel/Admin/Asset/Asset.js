import React from 'react'

function Asset() {
  return (
    <div>
      Admin Asset
    </div>
  )
}

export default Asset
