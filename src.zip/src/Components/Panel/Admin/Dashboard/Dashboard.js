import React from 'react'

function Dashboard() {
  return (
    <div>
      Admin Dashboard
    </div>
  )
}

export default Dashboard
