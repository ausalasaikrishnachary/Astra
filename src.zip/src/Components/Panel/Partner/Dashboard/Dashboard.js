import React from 'react'

function Dashboard() {
  return (
    <div>
      Partner Dashboard
    </div>
  )
}

export default Dashboard
