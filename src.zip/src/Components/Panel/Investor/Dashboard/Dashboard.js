import React from 'react'

function Dashboard() {
  return (
    <div>
      Investor Dashboard
    </div>
  )
}

export default Dashboard
